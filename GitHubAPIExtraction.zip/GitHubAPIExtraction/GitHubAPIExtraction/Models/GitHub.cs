﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GitHubAPIExtraction.Models
{
    public class GitHub
    {
        public string GitHubLinkUserProvided { get; set; }
        public string GitHubUserName { get; set; }
        public const string GitHubAPIAddress = "https://api.github.com";
        public string GitHubReturn { get; set; }
        //public const string regexURL = @"/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/";
        public const string regexGitHubURL = @"/(?:https\:\/\/)?github(?:.*)(?:\/)?/";

        public GitHub()
        {
            //GitHubLinkUserProvided = "https://github.com/henriquebelotto";
        }

        public string GetGitHubAPIAddress()
        {
            return GitHubAPIAddress;
        }


        public GitHub(string strGitHubLinkUserProvided)
        {
            this.GitHubLinkUserProvided = strGitHubLinkUserProvided;
        }

        /// <summary>
        /// Obtain the Username from the GitHub link provided by the user
        /// If it's not possible, return N/A for the username
        /// </summary>
        /// <returns></returns>
        public string GetUserName()
        {

            // Instantiate the regular expression object.
            Regex regex = new Regex(regexGitHubURL, RegexOptions.IgnoreCase);

            string[] words;
            try
            {
                // Matches for a GitHubURL
                Match match = regex.Match(this.GitHubLinkUserProvided.ToString());
                if (match.Success)
                {
                    // Split the provided url into segments
                    words = new Uri(this.GitHubLinkUserProvided).Segments;

                    // If the last segment contains "/", then split it again and remove the "/"
                    if (words[words.Length - 1].Contains("/"))
                    {
                        this.GitHubUserName = words[words.Length - 1].Split('/')[0];
                    }
                    else
                    {
                        this.GitHubUserName = words[words.Length - 1];
                    }
                }
                else
                {
                    this.GitHubUserName = "N/A";
                }
            }
            catch (Exception e)
            {
                // URL provided is not an GitHub or contain an error
                this.GitHubUserName = "N/A";
            }
            return this.GitHubUserName;

        }

    }
}
