﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GitHubAPIExtraction.Models
{
    public class Repository
    {
        public string name { get; set; }
        public string  language { get; set; }

        public override string ToString()
        {
            return $"Repository: {name} - Language: {language}";
        }

    }
}
