﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

// install-package Microsoft.AspNet.WebApi.Client - REQUIRED

namespace GitHubAPIExtraction.Models
{
    public class GitHubConnection
    {
        public HttpClient httpClient;

        public GitHubConnection()
        {
            this.httpClient = new HttpClient();
            this.httpClient.BaseAddress = new Uri("https://api.github.com");
            this.httpClient.DefaultRequestHeaders.Add("User-Agent",
            "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome / 58.0.3029.110 Safari / 537.36");
            this.httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/vnd.github.v3+json"));
        }


        public HttpResponseMessage GetGitHubResponse(string link)
        {
            using (httpClient)
            {
                var response = this.httpClient.GetAsync(link).Result;
                return response;
            }
        }
    }

}
