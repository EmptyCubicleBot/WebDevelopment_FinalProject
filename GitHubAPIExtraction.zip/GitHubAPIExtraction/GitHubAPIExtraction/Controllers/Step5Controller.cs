﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GitHubAPIExtraction.Models;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace GitHubAPIExtraction.Controllers
{
    public class Step5Controller : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [Route("searchgithub")]
        public async Task<ActionResult> searchgithub()
        {

            //GitHub gitHubObj = new GitHub(GitHubLinkUserProvided);
            //GitHub gitHubObj = new GitHub("https://github.com/henriquebelotto");
            GitHub gitHubObj = new GitHub("https://github.com/StephenTomlin");
            HttpResponseMessage GitHubAPIresponse;
            List<Repository> repositories = new List<Repository>();
            string repositoryListToString = "";

            gitHubObj.GetUserName();

            GitHubConnection gitHubConnection = new GitHubConnection();



            //using (HttpClient httpClientTest = new HttpClient())
            //{
            //    httpClientTest.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36");
            //   // gitHubObj.GitHubReturn = await httpClientTest.GetStringAsync($"https://api.github.com/users/{gitHubObj.GetUserName()}/repos");
            //    gitHubObj.GitHubReturn = await httpClientTest.GetStringAsync($"https://api.github.com/users/henriquebelotto/repos");

            //}

            string link = gitHubObj.GetGitHubAPIAddress() + "/users/" + gitHubObj.GetUserName() + "/repos";

           
            try
            {
                GitHubAPIresponse = gitHubConnection.GetGitHubResponse(link);
                GitHubAPIresponse.EnsureSuccessStatusCode();
                repositories = await GitHubAPIresponse.Content.ReadAsAsync<List<Repository>>();
                
                // Or this one, I don't know the difference
               // repositories = GitHubAPIresponse.Content.ReadAsAsync<List<Repository>>().Result;
            } catch (Exception e)
            {
                // This way, it does not write in the browser console
               // Console.WriteLine("Git Hub API connection unsuccessful");
            }

            foreach (Repository repository in repositories)
            {
                repositoryListToString +=  repository.ToString();
            }

            ViewBag.Repositories = repositoryListToString;

            //gitHubObj.GitHubReturn = await gitHubConnection.httpClient.GetStringAsync(link);
            //gitHubObj.GitHubReturn = await gitHubConnection.httpClient.GetStringAsync(link);
            //ViewBag.GitHubReturn = gitHubObj.GitHubReturn;


            //ViewBag.GitHubReturn = gitHubObj.GetList(gitHubObj.GitHubReturn);








            return View();

        }
    }
}